#pragma once
inline int resolutionx = 800;
inline int resolutiony = 600;
inline int mousex;
inline int mousey;
inline bool mouse_pressed = false;


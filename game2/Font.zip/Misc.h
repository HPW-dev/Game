#pragma once
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

void rendercircle(sf::RenderWindow &window, float x, float y, float radius, sf::Color color)
{
	sf::CircleShape circle(radius);
	circle.setPosition({ x-radius,y-radius });
	circle.setFillColor(color);
	window.draw(circle);
}
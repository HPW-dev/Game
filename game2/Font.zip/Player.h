#pragma once
#include "Game_Object.h"
#include "Objects.h"
#include <SFML/Window.hpp>
#include "Game_Core.h"
#include <iostream>


void makeplayer() {
	Game_Object player;
    player.type = Type::player;
	player.x = 200;
	player.y = 100;
	player.speed = 2.5;
	player.hitbox = 30;
	player.color = { 255,100,97 };
	objects.push_back(player);
}
void bullets(Game_Object& player) {
    if (player.shot_time <= 0) {
        Game_Object bullet;
        bullet.type = Type::bullet;
        bullet.x = player.x;
        bullet.y = player.y;
        bullet.speed = 6;
        bullet.hitbox = 10;
        bullet.color = { 173,255, 47 };
        bullet.vx = 10;
        bullet.vy = 0;
        objects.push_back(bullet);
    }

}
void moveplayer(Game_Object &player) {
    bool key_UP = sf::Keyboard::isKeyPressed(sf::Keyboard::Scan::W);
    bool key_LEFT = sf::Keyboard::isKeyPressed(sf::Keyboard::Scan::A);
    bool key_DOWN = sf::Keyboard::isKeyPressed(sf::Keyboard::Scan::S);
    bool key_RIGHT = sf::Keyboard::isKeyPressed(sf::Keyboard::Scan::D);
    if (key_UP) {
        player.y -= player.speed;
    }
    if (key_DOWN) {
        player.y += player.speed;
    }
    if (key_LEFT) {
        player.x -= player.speed;
    }
    if (key_RIGHT) {
        player.x += player.speed;
    }
    //�������� ������������ � �����
    if (player.x < 0) {
        player.x = resolutionx - player.hitbox * 2;
    }
    if (player.y < 0) {
        player.y = resolutiony - player.hitbox * 2;
    }
    if (player.x > resolutionx - player.hitbox * 2) {
        player.x = 0;
    }
    if (player.y > resolutiony - player.hitbox * 2) {
        player.y = 0;
    }
    if (mouse_pressed)
    {
        bullets(player);
    }
    
}

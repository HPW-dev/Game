#pragma once
#include "Game_Object.h"
#include <vector>

inline std::vector<Game_Object> objects;
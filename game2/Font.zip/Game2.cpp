﻿#pragma warning(push)
#pragma warning(disable: 4275)
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "Player.h"
#include "Bot1.h"
#include "Menu.h"
#include "Font.h"
#pragma warning(pop)

#include "Game_Core.h"
#include "Misc.h"
#include "Game_Object.h"

int main() {
    next_menu(menu_Type::basic_menu);
    makeplayer();
    for (size_t i = 0; i < 100; i++)
    {
    makebot1();

    }
    int fps = 0;
    std::string fps_txt;
    sf::Vector2u size(resolutionx, resolutiony);
    sf::RenderWindow window(sf::VideoMode(size), "SFML Window");
    window.setFramerateLimit(300);
    window.setVerticalSyncEnabled(false);
    sf::Clock time;
    loadingfont("Abbieshire.ttf");

    while (window.isOpen()) {//главный цикл игры
        while (auto event = window.pollEvent()) {
            /* условия для выхода: Выйти через кнопку
            Escape или через нажатие по крестику на окне */
            if (sf::Mouse::isButtonPressed(sf::Mouse::Button::Left)) {
            
                sf::Vector2i globalPosition = sf::Mouse::getPosition(window);
                mousex = globalPosition.x;
                mousey = globalPosition.y;
                mouse_pressed = true;
            }
            else {
                mouse_pressed = false;            
            }
            bool is_closed = event->is<sf::Event::Closed>();
            bool is_escape = event->is<sf::Event::KeyPressed>() && event->getIf<sf::Event::KeyPressed>()->code == sf::Keyboard::Key::Escape;
            if (is_closed)
                window.close();
            if (is_escape) {
                back();
            }
            

        }
        fps += 1;
        if (time.getElapsedTime().asSeconds()>=1)
        {
            fps_txt = std::to_string(fps);
            time.reset();
            fps = 0;
        }
        if (history_of_menu.empty())
            next_menu(menu_Type::yes_no);
        window.clear(); // стереть предыдущий кадр
        update_menu();
        currentmenu(window);
        drawtxt(window, fps_txt, 5, 5, 20);
        
 
        

        window.display(); // показать кадр
    }
}
#pragma once
#include "Game_Object.h"
#include "Objects.h"
#include "Game_Core.h"

void makebot1() {
	Game_Object bot1;
	bot1.type = Type::bot;
	bot1.x = rand()%resolutionx;
	bot1.y = rand()%resolutiony;
	bot1.speed = 2.5;
	bot1.hitbox = 15;
	bot1.color = { 0,255,0 };
	objects.push_back(bot1);

}
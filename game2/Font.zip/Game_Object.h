#pragma once
#include <SFML/Graphics.hpp>
enum class Type {
	player,
	bot,
	bullet
};
struct Game_Object
{
	float x, y;
	float hitbox;
	sf::Color color;
	int hp;
	int damage;
	Type type;
	float speed;
	float buff_on_damage;
	float buff_on_def;
	float buf_on_recharge_speed;
	float buff_on_speed;
	float radius_of_weapon;
	float weapon_size;
	float vx, vy;
	int shot_delay;
	int shot_time;
};
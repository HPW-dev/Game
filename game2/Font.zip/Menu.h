#pragma once
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "Font.h"
#include <vector>
#include "Game_Core.h"
#include "Misc.h"
#include "Game_Object.h"
#include "Player.h"
#include "Bot1.h"
#include <iostream>
#include "Rec.h"

enum class menu_Type {
	basic_menu,
	game_scene,
	settings,
	yes_no,
	results,
};
std::vector <menu_Type> history_of_menu;
void next_menu(menu_Type menu) {
	history_of_menu.push_back(menu);
}
void back() {
	history_of_menu.pop_back();
}
void update_mainmenu(sf::RenderWindow& window) {
	drawtxt(window, "Start", 363, 232, 60);
	if (mouse_pressed == true)
	{

		Rectangle rec;
		rec.x = 366;
		rec.y = 253;
		rec.max_x = 100;
		rec.max_y = 40;
		if (in_Rectangle(rec, mousex, mousey)) {
			next_menu(menu_Type::game_scene);
		}
	}
}
void yes_or_no(sf::RenderWindow& window) {
	drawtxt(window, "Yes", 363, 232, 60);
	drawtxt(window, "No", 220, 232, 60);
	drawtxt(window, "Exit game?", 220, 300, 90);
	if (mouse_pressed == true)
	{

		Rectangle rec;
		rec.x = 366;
		rec.y = 253;
		rec.max_x = 100;
		rec.max_y = 40;
		if (in_Rectangle(rec, mousex, mousey))
			std::exit(0);
		else next_menu(menu_Type::basic_menu);
		
	}
}
void settings(sf::RenderWindow& window) {
	drawtxt(window, "Resolution", 363, 232, 60);
	drawtxt(window, "Vertical Sinhronization", 220, 232, 60);
	if (mouse_pressed == true)
	{

		Rectangle rec;
		rec.x = 366;
		rec.y = 253;
		rec.max_x = 100;
		rec.max_y = 40;
		if (in_Rectangle(rec, mousex, mousey))
			std::exit(0);
		else next_menu(menu_Type::basic_menu);

	}
}
void update_game_scene(sf::RenderWindow& window) {
	auto& player = objects[0];
	moveplayer(player);
	for (auto& object : objects)
	{
		rendercircle(window, object.x, object.y, object.hitbox, object.color);

	}
}
inline auto currentmenu = &update_mainmenu;
void update_menu() {
	auto menu = history_of_menu.back();
	switch (menu)
	{
	case menu_Type::basic_menu:currentmenu = &update_mainmenu; break;
	case menu_Type::game_scene:currentmenu = &update_game_scene; break;
	case menu_Type::yes_no:currentmenu = &yes_or_no; break;
		
	default:
		break;
	}
}